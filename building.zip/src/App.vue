<template>
  <div id="3d"></div>
</template>

<script>
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
const floors = new Object();

let offset;

const directionalLight = new THREE.DirectionalLight(0xffffff, 2);
scene.add(directionalLight);


const light = new THREE.AmbientLight(0x404040, 10); // soft white light
scene.add(light);

const size = 14;
const divisions = 14;

const gridHelper = new THREE.GridHelper(size, divisions);
scene.add(gridHelper);

function createBuilding(floors) {
  const geometry = new THREE.BoxGeometry(6, 1, 6);
  const material = new THREE.MeshPhysicalMaterial({
    color: 0x4f9fdd,
    wireframe: false,
    transmission: 0.148,
    transparent: true,
    opacity: 0.15,
    metalness: 0.2,
    roughness: 0.8,
    ior: 1.5,
    specularIntensity: 0.1,
    envMapIntensity: 0.06,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  for (let i = 0; i < floors; i++) {
    const cube = new THREE.Mesh(geometry, material);
    cube.position.set(0, i + 0.5, 0);
    scene.add(cube);
  }
}

function createShaft(floors, x, z, color) {
  const liftGeometry = new THREE.BoxGeometry(1, 1, 1);
  const liftMaterial = new THREE.MeshPhysicalMaterial({
    color: color,
    wireframe: false,
    transmission: 0.148,
    transparent: true,
    opacity: 0.15,
    metalness: 0.2,
    roughness: 0.8,
    ior: 1.5,
    specularIntensity: 0.1,
    envMapIntensity: 0.06,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  for (let i = 0; i < floors; i++) {
    const liftCube = new THREE.Mesh(liftGeometry, liftMaterial);
    liftCube.position.set(x, i + 0.5, z);
    scene.add(liftCube);
  }
}


const lift = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1, 0.5), new THREE.MeshPhysicalMaterial({
  color: "yellow"
}))

lift.position.set(-0.5, 1 / 2, 0.5);

scene.add(lift)



camera.position.z = 15;

const clock = new THREE.Clock();


const state = {
  Lift_direction: false
}


function animate() {
  floors.x = 20;

  //  = Math.sin(100) * clock.getDelta() * 10;
  // console.log()
  if (lift.position.y + 0.5 < 20) {
    lift.position.y += 1 / 2 * clock.getDelta() * 2;
  } else {
    console.log(lift.position.y)
    lift.position.y + 20 - 0.5;
  }




  // if (lift.position.y == 19) {
  //   lift.position.y -= 0.85 / 2 * clock.getDelta() * 5;
  // } else if (lift.position.yellow <= 0) {
  //   lift.position.y += 0.85 / 2 * clock.getDelta() * 5;
  // } else {
  //   lift.position.y += 0.85 / 2 * clock.getDelta() * 5;
  // }

  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}

export default {
  mounted() {
    const floors = 20;
    camera.position.z = floors * 1.4;
    offset = -floors / 2;
    createBuilding(floors);
    // createLift(floors, 3, 0, 2, 1, 1, 0x1350F5);
    createShaft(floors, -1.5, 0.5, 0x00ffbf);
    createShaft(floors, -0.5, 0.5, 0x00ffbf);
    document.getElementById('3d').appendChild(renderer.domElement);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.listenToKeyEvents(window); // optional
    animate();
  }
};
</script>
