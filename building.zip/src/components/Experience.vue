<template>
    <div id="3d"></div>
</template>

<script setup lang="js" allowJs="true">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
const floors = new Object();

let offset;

function createBuilding(floors) {
    const geometry = new THREE.BoxGeometry(8, 1, 8);
    const material = new THREE.MeshBasicMaterial({ color: 0x00ff00, transparent: true, opacity: 0.1 });
    for (let i = 0; i < floors; i++) {
        const cube = new THREE.Mesh(geometry, material);
        cube.position.set(0, i + offset, 0);
        scene.add(cube);
    }
}
function createLift(floors, x, y, z, color) {
    const liftGeometry = new THREE.BoxGeometry(1, floors, 1);
    const liftMaterial = new THREE.MeshBasicMaterial({
        color: color,
        transparent: false,
        opacity: 0.8
    });
    const liftCube = new THREE.Mesh(liftGeometry, liftMaterial);
    liftCube.position.set(x, y + offset, z);
    scene.add(liftCube);
}

camera.position.z = 15; //-offset*2;

function animate() {
    floors.x = 20;
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}

export default {
    mounted() {
        const floors = 20;
        camera.position.z = floors * 1.4;
        offset = -floors / 2;
        createBuilding(floors);
        createLift(floors, 4, floors / 2 - 0.5, 2, 0xa0a0a0);
        createLift(floors, -1, floors / 2 - 0.5, 1, 0x0000ff);
        createLift(floors, -1, floors / 2 - 0.5, -1, 0x0000ff);
        document.getElementById('3d').appendChild(renderer.domElement);
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.listenToKeyEvents(window); // optional
        animate();
    }
};
</script>